export const skills = [
    {
        id: 1,
        name: "HTML"
    },
    {
        id: 2,
        name: "CSS"
    },
    {
        id: 3,
        name: "Java Script"
    },
    {
        id: 4,
        name: "React"
    },
    {
        id: 5,
        name: "Next js"
    },
    {
        id: 6,
        name: "Angular"
    },
    {
        id: 7,
        name: "Node"
    },
    {
        id: 8,
        name: "Java"
    },
    {
        id: 9,
        name: "PHP"
    },
    {
        id: 10,
        name: "C++"
    }
]