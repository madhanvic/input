"use client";

import { useState } from "react";
import DynamicDropdown from "./component/DynamicDropdown";
import Input from "./component/Input";
import PositionDropDown from "./component/PositionDropDown";
import Dropdown from "./component/dropDown";
import DynamicEnterDropdown from "./component/DynamicEnterDropdown";

function Home() {
  const [inputValue, setInputValue] = useState("");
  const [inputValue1, setInputValue1] = useState("");
  const [enterValues, setEnterValues] = useState([]);
  const handler = (e) =>{
      e.preventDefault();
      // console.log(e);
  }
  console.log(enterValues);
  return (
    <>
    <form onSubmit={handler} className="h-screen flex flex-col justify-center items-center gap-y-5">
      <Input extraStyles={`auth__input`} name={"email"}>Email address</Input>
      <Dropdown extraStyles={`auth__input`} name={"skills"}>Skills</Dropdown>
      <Dropdown extraStyles={`auth__input`} name={"skills1"}>Skills1</Dropdown>
      <PositionDropDown extraStyles={`auth__input`} name={"skills2"}>Skills2</PositionDropDown>
      <DynamicDropdown value={inputValue} setInputValue={setInputValue}  extraStyles={`auth__input`} name={"location"} api = "http://api.dev.uxdjobs.com/v1/cities" query={{search:inputValue}} >Location</DynamicDropdown>
      <button type="submit">Submit</button>
    </form>
    <div className="h-screen flex flex-col justify-center items-center gap-y-5">
      <DynamicEnterDropdown setEnterValues={setEnterValues} value={inputValue1} setInputValue={setInputValue1}  extraStyles={`auth__input`} name={"location1"} api = "http://api.dev.uxdjobs.com/v1/cities" query={{search:inputValue1}}>Location 1</DynamicEnterDropdown>
    </div>
    </>
  )
}


export default Home;