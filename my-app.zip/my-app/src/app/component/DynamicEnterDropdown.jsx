import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Label from "./Label";
import PositionDropDownOption from "./PositonDropDownOptions";
import useSWR from "swr";

const DynamicEnterDropdown = ({setEnterValues, api, type, children, extraStyles, name,value, setInputValue, query}) =>{
    const [lineHeight, setLineHeight] = useState("");
    const [isFocused, setIsFocused] = useState(false);
    const [position, setPosition] = useState({});


    const inputRef = useRef(null);
       

    useEffect(()=>{
        const setPositionHandler = () =>{

            const {bottom, left, width} = inputRef.current.getBoundingClientRect()
            setPosition({bottom, left, width})
        }

        window.addEventListener("scroll", setPositionHandler);

        return() => window.removeEventListener("scroll", setPositionHandler)
    }, [])

    const fetcher = async([url, options]) =>{
        const response = await fetch(url, options);
        const parsedResponse = await response.json();
        if(!response.ok){
            throw ({error: parsedResponse.message})
        }
        return parsedResponse;
    }

    const paramsOBJ = new URLSearchParams(query);
    const queryString = paramsOBJ.toString();
    const { data, error, isLoading, isValidating, mutate } = useSWR([`${api}?${queryString}`, {method: "GET"}], fetcher)

    const onBlurHandler = (e) =>{
        if (!e.currentTarget.contains(e.relatedTarget) && !e.relatedTarget?.matches(`.${name}id`) ) {
            setIsFocused(false);
          }
    }
    const onFocusHandler = () =>{
    const {bottom, left, width} = inputRef.current.getBoundingClientRect();
    setIsFocused(true);
    setPosition({bottom, left, width})
    }
    const optionHandler = useCallback((option) =>{
        setEnterValues((prevState)=>{
            const index = prevState.findIndex((opt)=> opt === option);
            console.log(index);
            if(index >= 0){
                return prevState
            }

            return [...prevState, option];
        })
        setInputValue("");
        setIsFocused(false);
        inputRef.current.blur()
  
    }, [setInputValue, setIsFocused, setEnterValues])

   const keyPressHandler = (e) =>{
    if(e.key === "Enter"){
            
        optionHandler(e.target.value)
        return;
    }
   }

    const onChangeHandler = (e) =>{

        setInputValue(e.target.value);
    }

    const memoOptions = useMemo(()=>data?.data?.length ? data?.data : [], [data]);
    const memoPosition = useMemo(()=> position, [position])
    
  
    return(
        <div className={`${extraStyles}`} onBlur={onBlurHandler} onFocus={onFocusHandler} >
        <input onKeyDown={keyPressHandler} ref={inputRef} value={value}  onChange={onChangeHandler} id={name} name={name} type={type} style={{paddingTop: `${lineHeight + 2}px`}} autoComplete="off"/>
        <Label name={name} setLineHeight={setLineHeight} isFocused={isFocused || value.length > 0 }>{children}</Label>
        {isFocused && <PositionDropDownOption name={`${name}id`} setInputValue={optionHandler} options={memoOptions} position={memoPosition}/>}
    </div>  
    )
}

export default DynamicEnterDropdown;