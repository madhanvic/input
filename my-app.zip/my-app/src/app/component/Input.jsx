
import { useState } from "react";
import Label from "./Label";

const Input = ({type, children, extraStyles, name}) =>{
    const [lineHeight, setLineHeight] = useState("");
    const [isFocused, setIsFocused] = useState(false);

    const onBlurHandler = (e) =>{
       if(e.target.value <= 0 ){
        setIsFocused(false)
       }
    }
    const onFocusHandler = () =>{
       setIsFocused(true);
    }

  return(
    <div className={`${extraStyles}`}>
        <input id={name} name={name} type={type} style={{paddingTop: `${lineHeight + 2}px`}} onBlur={onBlurHandler } onFocus={onFocusHandler} autoComplete="off"/>
        <Label name={name} setLineHeight={setLineHeight} isFocused={isFocused}>{children}</Label>
    </div>
  )
}

export default Input;

