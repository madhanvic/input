const DropdownOptions = ({setInputValue, options}) =>{

    return(
        <ul>
        {
            options.map((option)=>{
             return(
                <li key={option.id}>
                <button onClick={setInputValue.bind(null, option.name)}>{option.name}</button>
            </li>
             )
            })
        }

        </ul>
    )
}


export default DropdownOptions;