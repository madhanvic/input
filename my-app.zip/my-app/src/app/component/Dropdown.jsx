import { useCallback, useMemo, useState } from "react";
import Label from "./Label";
import DropdownOptions from "./DropdownOptions";
import { skills } from "../../../constants/Arrays";


const Dropdown = ({api, type, children, extraStyles, name }) =>{
    const [lineHeight, setLineHeight] = useState("");
    const [isFocused, setIsFocused] = useState(false);
    const [inputValue, setInputValue] = useState("");
    const [options, setOptions] = useState(skills);

    const onBlurHandler = (e) =>{
        console.log(e);
        if (!e.currentTarget.contains(e.relatedTarget)) {
            setIsFocused(false)
          }
    }
    const onFocusHandler = () =>{
       setIsFocused(true);
    }
    const optionHandler = useCallback((option, e) =>{
        console.log(option);
        setInputValue(option);
        setIsFocused(false);
    }, [])

    const onChangeHandler = (e) =>{
       setInputValue(e.target.value);
       const filteredOptions = skills.filter((option)=> option.name.toLowerCase().includes(e.target.value.toLowerCase()));
       setOptions(filteredOptions);
    }


    const memoOptions = useMemo(()=>options, [options]);
  
    return(
    <div className={`${extraStyles}`} onBlur={onBlurHandler } onFocus={onFocusHandler} >
        <input value={inputValue}   onChange={onChangeHandler} id={name} name={name} type={type} style={{paddingTop: `${lineHeight + 2}px`}} autoComplete="off"/>
        <Label name={name} setLineHeight={setLineHeight} isFocused={isFocused || inputValue.length > 0 }>{children}</Label>
        {isFocused && <DropdownOptions setInputValue={optionHandler} options={memoOptions}/>}
    </div>
    )
}

export default Dropdown;


