import { createPortal } from "react-dom";


const PositionDropDownOption = ({setInputValue, options, position, name}) =>{

    return(
     createPortal(<ul  className={`fixed dropdownOPtion ${name}`} style={{top: `${position.bottom + 8}px`, left:`${position.left}px`, width: `${position.width}px`}}>
     {
         options.map((option)=>{
          return(
             <li key={option.id} className={`${name}`}>
             <button onClick={setInputValue.bind(null, option.name)} className={`${name}`}>{option.name}</button>
         </li>
          )
         })
     }

     </ul>, document.body)
    )
}

export default PositionDropDownOption;