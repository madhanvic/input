import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from "react";
import Label from "./Label";
import { skills } from "../../../constants/Arrays";
import PositionDropDownOption from "./PositonDropDownOptions";

const reducer = (state, action) =>{
    switch (action.type) {
        

        case "dropdown/isFocused/true":{
            return{
                ...state,
                position : action.payload.position,
                isFocused:true
            }
        }
            
        case "dropdown/isFocused/false":{
            return{
                ...state,
                isFocused:false
            }
        }

        case "dropdown/position":{
            return{
                ...state,
                position : action.payload.position
            }
        }

        case "dropdown/input":{
            return{
                ...state,
                input: action.payload.value
            }
        }

        case "dropdown/filter/options":{
            return{
                ...state,
                input: action.payload.value,
                filteredOptions: action.payload.options
            }
        }

        case "dropdown/filter/options/select":{
            return{
                ...state,
                input: action.payload.value,
                isFocused:false
            }
        }
    
        default: {
            return state
        }
    }
}


const PositionDropDown = ({ type, children, extraStyles, name}) =>{

    
    const [lineHeight, setLineHeight] = useState("");

    const [state, dispatch] = useReducer(reducer, {
        isFocused : false,
        position:{},
        input:"",
        filteredOptions: skills
    });

    const inputRef = useRef(null);


    useEffect(()=>{
        const {bottom, left, width} = inputRef.current.getBoundingClientRect()
        dispatch({type:"dropdown/position", payload: {position:{bottom, left, width}}})
    }, [])

  


    const onBlurHandler = (e) =>{
        if (!e.currentTarget.contains(e.relatedTarget) && !e.relatedTarget?.matches(`.${name}id`) ) {
            console.log("worked");
            dispatch({type: "dropdown/isFocused/false"})
          }
    }
    const onFocusHandler = () =>{
    const {bottom, left, width} = inputRef.current.getBoundingClientRect();
    dispatch({type:"dropdown/isFocused/true", payload: {position:{bottom, left, width}}})
    }
    const optionHandler = useCallback((option) =>{
        dispatch({type:"dropdown/filter/options/select", payload: {value: option}})
    }, [])

    const onChangeHandler = (e) =>{
       const filteredOptions = skills.filter((option)=> option.name.toLowerCase().includes(e.target.value.toLowerCase()));
       dispatch({type:"dropdown/filter/options", payload: {value :e.target.value, options: filteredOptions}})
    }

    
    const memoOptions = useMemo(()=>state.filteredOptions, [state.filteredOptions]);
    const memoPosition = useMemo(()=> state.position, [state.position])
    return(
        <div className={`${extraStyles}`} onBlur={onBlurHandler } onFocus={onFocusHandler} >
        <input  ref={inputRef} value={state.input}  onChange={onChangeHandler} id={name} name={name} type={type} style={{paddingTop: `${lineHeight + 2}px`}} autoComplete="off"/>
        <Label name={name} setLineHeight={setLineHeight} isFocused={state.isFocused || state.input.length > 0 }>{children}</Label>
        {state.isFocused && <PositionDropDownOption name={`${name}id`} setInputValue={optionHandler} options={memoOptions} position={memoPosition}/>}
    </div>
    )
}

export default PositionDropDown;