import { useEffect, useRef} from "react";



const Label = ({children, setLineHeight, isFocused, name}) =>{
    const labelRef =  useRef();
    useEffect(()=>{
        const getLineHeight = function(element) {
            const lineHeight = window.getComputedStyle(element)['line-height'];
            if (lineHeight === 'normal') {
              // fuck chrome
              return 1.16 * parseFloat(window.getComputedStyle(element)['font-size']);
            } else {
              return parseFloat(lineHeight);
            }
          }

        const lineHeight = getLineHeight(labelRef.current);
        setLineHeight(lineHeight)
    }, [labelRef, setLineHeight])
  

    return(
        <label  ref={labelRef} className={`${isFocused ? "active" : undefined}`} htmlFor={name}>
            {children}
        </label>
    )
}

export default Label;

